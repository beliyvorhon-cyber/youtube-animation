from faster_whisper import WhisperModel
from pathlib import Path
import wave,json
import numpy as np
r=Path(__file__).parent
with wave.open(str(r/'analysis.wav')) as f:a=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(np.float32)/32768
m=WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=2,download_root=str(r/'models'))
rows=[]
for start,end in [(23,34),(25.5,30),(69,78),(127,137),(148,155.1557)]:
 segs,_=m.transcribe(a[int(start*16000):int(end*16000)],language='en',beam_size=5,word_timestamps=True,condition_on_previous_text=False)
 for s in segs:
  d={'start':start+s.start,'end':start+s.end,'text':s.text,'words':[{'start':start+w.start,'end':start+w.end,'word':w.word,'probability':w.probability} for w in s.words]};rows.append(d);print(f"{d['start']:.2f}-{d['end']:.2f} {s.text}",flush=True)
(r/'targeted_recheck.json').write_text(json.dumps(rows,indent=2))
