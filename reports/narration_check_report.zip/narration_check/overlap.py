from pathlib import Path
import wave,json
import numpy as np
import onnxruntime as ort
r=Path(__file__).parent
with wave.open(str(r/'analysis.wav')) as f:a=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(np.float32)/32768
opt=ort.SessionOptions();opt.intra_op_num_threads=2;opt.inter_op_num_threads=1
s=ort.InferenceSession(str(r/'overlap.onnx'),sess_options=opt,providers=['CPUExecutionProvider'])
print('Input/output',s.get_inputs()[0].shape,s.get_outputs()[0].shape,flush=True)
def infer(z):
 y=s.run(None,{'input_values':z[None,None,:]})[0][0]
 p=np.exp(y-y.max(axis=-1,keepdims=True));p/=p.sum(axis=-1,keepdims=True)
 return p
bins=int(np.ceil(len(a)/16000/.02));total=np.zeros(bins);counts=np.zeros(bins)
for start in range(0,len(a),80000):
 z=a[start:start+160000];real=len(z);z=np.pad(z,(0,160000-len(z)))
 p=infer(z);times=(start+990+np.arange(len(p))*270)/16000
 idx=np.floor(times/.02).astype(int);valid=(idx<bins)&(times<(start+real)/16000)
 np.add.at(total,idx[valid],p[valid,4:].sum(axis=-1));np.add.at(counts,idx[valid],1)
score=total/np.maximum(counts,1);mask=score>.5
segments=[];start=None
for i,b in enumerate(np.r_[mask,False]):
 if b and start is None:start=i
 elif not b and start is not None:
  if (i-start)*.02>=.12:segments.append({'start':start*.02,'end':i*.02,'max_probability':float(max(score[start:i]))})
  start=None
control=.5*a[:160000]+.5*a[480000:640000]
p=infer(control);ctrl=p[:,4:].sum(axis=-1)
d={'model':'onnx-community/pyannote-segmentation-3.0','frame_bin_seconds':.02,'overlap_threshold':.5,'flagged_intervals':segments,'max_overlap_probability':float(score.max()),'seconds_above_threshold':float(mask.sum()*.02),'synthetic_overlap_control_fraction_above_threshold':float(np.mean(ctrl>.5)),'synthetic_overlap_control_max':float(ctrl.max()),'limitations':'Model estimate, not a proof. Identical-voice overlap can be missed. Control is a local diagnostic mix, not a repaired narration.'}
(r/'overlap_report.json').write_text(json.dumps(d,indent=2));np.save(r/'overlap_probabilities.npy',score);print(json.dumps(d,indent=2),flush=True)
