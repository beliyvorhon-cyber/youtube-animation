from faster_whisper import WhisperModel
from pathlib import Path
import json,time,wave
import numpy as np
r=Path(__file__).parent
model=WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=2,download_root=str(r/'models'))
print('Model ready',flush=True)
with wave.open(str(r/'analysis.wav')) as f: audio=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(np.float32)/32768
segments,info=model.transcribe(audio,language='en',beam_size=5,word_timestamps=True,vad_filter=False,condition_on_previous_text=False)
rows=[]
for s in segments:
 d={'start':s.start,'end':s.end,'text':s.text,'avg_logprob':s.avg_logprob,'no_speech_prob':s.no_speech_prob,'words':[{'start':w.start,'end':w.end,'word':w.word,'probability':w.probability} for w in s.words]}
 rows.append(d);print(f'{s.start:7.2f} {s.end:7.2f} {s.text}',flush=True)
 (r/'transcript.json').write_text(json.dumps(rows,indent=2))
(r/'transcript.txt').write_text('\n'.join(f"[{d['start']:.2f}–{d['end']:.2f}] {d['text'].strip()}" for d in rows))
