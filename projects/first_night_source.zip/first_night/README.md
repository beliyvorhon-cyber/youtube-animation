# Первая ночь древнего человека

15-second original procedural 2D short. 1920×1080, 30 fps, H.264 / AAC stereo.

## Reproduce

Python 3.12+, FFmpeg (libx264 and AAC), Pillow, NumPy and SciPy are required.

```sh
python3 -m pip install -r requirements.txt
python3 render.py --out build
```

For four stills only: `python3 render.py --out build --preview`.
The full render also creates an original 48 kHz stereo WAV.
No network requests, paid services, stock images, sampled effects or third-party music are used by the renderer.

## Timeline

- 0–4 s: seated prehistoric man beside a cave; wind, crickets and sparse soft notes.
- 4–8 s: foliage rustles at 4.0, 5.4 and 7.3 seconds; startled reaction starts at 4.13; low semitone ostinato.
- 8–11 s: small rabbit emerges at 8.06 seconds and hops twice; synthesized spring sounds and quiet landing sounds.
- 11–15 s: exhale begins at 11.12; posture relaxes and mouth smiles; rabbit rests nearby; original major-key plucked melody begins at 11.35.

## Character and artwork

A deliberately simplified doodle adaptation of the user's supplied 54.jpg and 44.jpg: dark shaggy hair, heavy eyebrows, beard, prominent rounded nose, warm skin, diagonal one-shoulder hide garment, belt and leg wraps. The same procedural model is used for all 450 frames. Expressions and poses vary, not the design. The injury/splint in one reference is not included because this story does not establish an injury.

All backgrounds, rabbit, linework and audio are drawn or synthesized by `render.py`. The reference photographs/illustrations are not packaged or published in this project. Their rights are not asserted here.

## Implementation

Pillow draws flat shapes and thin outlines at 2880×1620, then downsamples to 1920×1080. Cubic easing drives reactions; breathing, blinking and ear movement continue during holds. NumPy/SciPy synthesize wind, insect pulses, rustles, spring effects, breath and plucked notes with deterministic randomness. FFmpeg encodes H.264 yuv420p and AAC 192 kbps, stereo 48 kHz, with a -18 LUFS target and fast-start MP4 layout.

No external publication occurs when running this script.
