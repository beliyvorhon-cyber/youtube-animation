"""First Night — original procedural 2D animation and sound.
Run: python3 render.py --out build
Requires Python 3, Pillow, numpy, scipy, ffmpeg / ffprobe.
All drawing and audio are generated here; no stock assets or music.
Character design is simplified from the two user-supplied references.
"""
from pathlib import Path
import argparse, math, subprocess, json, wave
import numpy as np
from PIL import Image, ImageDraw
from scipy.signal import butter, sosfilt

W,H,FPS,DURATION=1920,1080,30,15
S=3
INK='#292923'; SKIN='#c69768'; HAIR='#453b30'; FUR='#82715a'

def ease(x):
 x=max(0,min(1,x)); return x*x*(3-2*x)
def ramp(t,a,b): return ease((t-a)/(b-a))
def pulse(t,a,b,c): return ramp(t,a,b)*(1-ramp(t,b,c))

class Pen:
 def __init__(self,im,origin=(0,0),angle=0):
  self.d=ImageDraw.Draw(im); self.o=origin; self.a=math.radians(angle)
 def p(self,p):
  x,y=p;c=math.cos(self.a);s=math.sin(self.a)
  return ((self.o[0]+x*c-y*s)*S,(self.o[1]+x*s+y*c)*S)
 def line(self,pts,fill=INK,w=1.6):
  pts=[self.p(p) for p in pts];self.d.line(pts,fill=fill,width=max(1,round(w*S)),joint='curve')
  r=w*S/2
  for x,y in (pts[0],pts[-1]): self.d.ellipse((x-r,y-r,x+r,y+r),fill=fill)
 def poly(self,pts,fill,outline=INK,w=1.6):
  pp=[self.p(p) for p in pts];self.d.polygon(pp,fill=fill)
  if outline:self.line(pts+[pts[0]],outline,w)
 def ellipse(self,box,fill,outline=INK,w=1.5):
  x1,y1,x2,y2=box
  pts=[((x1+x2)/2+(x2-x1)/2*math.cos(a),(y1+y2)/2+(y2-y1)/2*math.sin(a)) for a in np.linspace(0,2*math.pi,49)]
  self.poly(pts,fill,outline,w)
 def curve(self,points,fill=INK,w=1.6):
  # Cubic Bezier, exactly four control points.
  pp=[]
  for u in np.linspace(0,1,24):
   q=(1-u)**3*np.array(points[0])+3*(1-u)**2*u*np.array(points[1])+3*(1-u)*u*u*np.array(points[2])+u**3*np.array(points[3]);pp.append(tuple(q))
  self.line(pp,fill,w)

def background():
 im=Image.new('RGB',(960*S,540*S),'#ccd5d1');p=Pen(im)
 p.poly([(0,274),(110,221),(194,254),(305,207),(403,260),(504,221),(618,267),(749,212),(860,244),(960,197),(960,460),(0,460)],'#b9c4bc',None)
 p.poly([(0,344),(135,294),(259,327),(398,289),(533,326),(675,278),(815,314),(960,276),(960,540),(0,540)],'#a5b09b',None)
 p.ellipse((751,58,798,105),'#eee8ce',None)
 p.ellipse((766,49,808,94),'#ccd5d1',None)
 for x,y in [(433,81),(566,136),(675,64),(844,154),(907,86),(350,148)]:
  p.line([(x-2,y),(x+2,y)],'#f5efda',1);p.line([(x,y-2),(x,y+2)],'#f5efda',1)
 p.poly([(0,398),(100,385),(230,401),(357,390),(505,405),(679,389),(815,403),(960,388),(960,540),(0,540)],'#d6cbb2',None)
 # Cave and flat rock planes.
 p.poly([(-30,414),(-16,230),(31,138),(114,108),(205,137),(281,230),(303,408)],'#9a9d8d')
 p.poly([(19,399),(49,246),(98,189),(167,190),(226,252),(257,403)],'#515b54')
 p.poly([(31,399),(72,265),(118,225),(176,236),(212,307),(228,402)],'#444d48',None)
 p.line([(30,140),(67,178),(45,234)],'#727b70',1.2)
 p.line([(115,109),(128,150),(196,168),(223,211)],'#727b70',1.2)
 p.line([(263,247),(238,273),(268,350)],'#727b70',1.2)
 p.poly([(1,405),(39,390),(66,401),(57,417),(4,420)],'#aaa996')
 p.poly([(252,409),(269,391),(294,389),(316,410),(287,419)],'#aaa996')
 # Spear from reference, resting beside cave.
 p.line([(226,406),(312,257)],'#4e4232',6)
 p.line([(226,406),(312,257)],'#927450',3.2)
 p.poly([(307,268),(312,234),(326,248),(315,272)],'#a2a391')
 for z in range(4):p.line([(304+z*1.6,269-z*2.6),(316+z*1.6,274-z*2.6)],'#645340',1.3)
 for x,y in [(85,457),(319,467),(532,441),(689,470),(885,441),(771,513),(194,513)]:
  p.curve([(x-9,y),(x-5,y-8),(x+5,y-8),(x+10,y)],'#aaa58e',1)
 for x,y in [(56,428),(176,437),(338,417),(702,422),(901,415)]:
  for k in range(3):p.line([(x,y),(x+(k-1)*7,y-9-(k%2)*5)],'#7d886d',1)
 return im
BASE=background()

def bush(im,t,front=False):
 shake=0
 for a,b,c in [(4,4.2,4.8),(5.4,5.7,6.1),(7.3,7.6,8.2)]:shake+=pulse(t,a,b,c)*math.sin(t*37)*4
 p=Pen(im,(shake,0))
 if not front:
  p.poly([(710,405),(692,382),(702,355),(728,350),(728,326),(755,332),(774,312),(798,328),(823,319),(841,344),(869,348),(876,371),(903,380),(891,409)],'#7e9178')
  for x,y in [(717,364),(755,347),(799,350),(838,370),(864,387)]:
   p.curve([(x-9,y),(x-2,y-7),(x+9,y-6),(x+13,y+2)],'#4d624f',1.1)
 else:
  p.poly([(747,409),(739,392),(754,382),(766,387),(780,369),(799,383),(816,380),(834,401),(850,410)],'#879b7e')
  p.curve([(759,399),(778,384),(803,396),(816,404)],'#50644f',1.1)

def human(im,t):
 alert=ramp(t,4.13,4.42)*(1-ramp(t,10.95,11.65))
 startle=pulse(t,4.13,4.29,4.65)
 sigh=pulse(t,11.05,11.35,12.1)
 breathe=1.1*math.sin(t*2.5)*(1-alert)
 yy=-7*startle+3*sigh+breathe
 p=Pen(im,(403,280+yy))
 # Feet, legs, consistent wrapped footwear.
 p.poly([(-31,91),(-1,84),(31,107),(50,126),(78,130),(81,143),(48,150),(17,132),(-15,125)],SKIN)
 p.poly([(-8,104),(27,97),(57,120),(69,139),(106,140),(113,152),(78,163),(49,156),(24,137),(-9,136)],SKIN)
 p.poly([(47,129),(67,126),(81,141),(74,153),(57,150)],'#6e5945')
 p.poly([(71,139),(88,138),(97,152),(83,161),(73,157)],'#6e5945')
 for k in range(3):
  p.line([(51+k*5,130),(61+k*5,149)],'#b5a184',1.7)
  p.line([(75+k*4,141),(82+k*4,158)],'#b5a184',1.7)
 for k in range(3):p.line([(101+k*3,145),(100+k*3,149)],INK,.9)
 # Torso: diagonal one-shoulder hide, bare right shoulder.
 p.poly([(-24,15),(-43,37),(-47,85),(-56,115),(-46,111),(-40,125),(-31,118),(-20,130),(-10,120),(3,130),(10,118),(27,122),(18,109),(28,88),(27,38),(11,18)],FUR)
 p.poly([(11,19),(29,27),(34,49),(18,63),(-28,85),(-38,69),(-3,39)],SKIN)
 p.poly([(-25,18),(-40,36),(-31,49),(22,82),(29,66),(-9,32)],FUR)
 p.line([(-33,42),(21,75)],'#b5a288',2)
 p.line([(-45,90),(19,100)],'#584733',5)
 p.line([(-44,89),(20,99)],'#a2885f',1.2)
 for x,y in [(-42,105),(-31,111),(-11,115),(8,111),(-29,34)]:p.line([(x,y),(x+2,y+5)],'#4e473b',1)
 # Arm raised slightly during alert; chest touch during relieved breath.
 armup=alert*12+sigh*19
 p.line([(-32,39),(-30,78-armup*.2),(11,105-armup)],INK,18)
 p.line([(-32,39),(-30,78-armup*.2),(11,105-armup)],SKIN,14)
 p.ellipse((4,97-armup,23,110-armup),SKIN,w=1)
 p.line([(24,37),(44,71-alert*10),(53,108-alert*24)],INK,15)
 p.line([(24,37),(44,71-alert*10),(53,108-alert*24)],SKIN,11.5)
 p.ellipse((46,101-alert*24,62,114-alert*24),SKIN,w=1)
 for k in range(3):p.line([(10+k*3,102-armup),(12+k*3,107-armup)],INK,.65)
 # Head rig: all design features stay identical; only pose / expression move.
 hx=403+alert*5;hy=265+yy
 h=Pen(im,(hx,hy),-3+alert*7)
 # Fixed shaggy hair silhouette.
 hair=[(-44,7),(-48,-8),(-41,-13),(-49,-24),(-37,-24),(-42,-38),(-25,-35),(-23,-49),(-13,-42),(-3,-54),(9,-43),(23,-51),(25,-39),(40,-40),(35,-29),(49,-24),(40,-16),(49,-4),(40,3),(42,21),(27,29),(-24,27)]
 h.poly(hair,HAIR,w=1.7)
 h.ellipse((-34,-30,34,36),SKIN,w=1.4)
 h.ellipse((-40,-3,-22,18),SKIN,w=1.3)
 h.curve([(-34,3),(-29,-3),(-24,8),(-31,11)],INK,1)
 # Hairline and beard, prominent reference traits.
 h.poly([(-31,-10),(-33,-29),(-20,-36),(-6,-32),(4,-40),(10,-28),(27,-29),(34,-16),(32,-3),(24,-15),(18,-20),(8,-14),(6,-24),(-6,-17),(-9,-25),(-22,-16)],HAIR,w=1.1)
 h.poly([(-29,8),(-22,16),(-17,13),(-12,21),(3,19),(11,13),(21,14),(29,8),(32,25),(26,39),(18,44),(12,42),(6,47),(-1,44),(-8,46),(-16,40),(-25,38),(-31,25)],HAIR,w=1.3)
 look=alert*5+(ramp(t,8.4,9.8)*2)
 blink=0
 for a in [1.5,3.2,10.2,13.3]:blink=max(blink,pulse(t,a,a+.09,a+.2))
 eyes=1-blink*.93
 for x,y,rx,ry in [(-11,-1,10,12),(15,1,9,11)]:
  ry*=eyes*(1+alert*.13)
  h.ellipse((x-rx,y-ry,x+rx,y+ry),'#f5edda',w=1)
  if eyes>.2:h.ellipse((x+look/2-1,y-2,x+look/2+3,y+3),INK,None)
 h.line([(-23,-17-alert*3),(-14,-20-alert*4),(-4,-16-alert*4)],HAIR,4)
 h.line([(8,-17-alert*4),(18,-17-alert*5),(25,-12-alert*3)],HAIR,3.7)
 h.ellipse((1,3,21,19),'#c28e5d',w=1)
 if alert>.4:h.ellipse((-4,25,16,32+alert*6),'#292621',w=1)
 elif sigh>.3:h.ellipse((3,24,13,31),'#292621',w=1)
 else:h.curve([(-7,26),(-1,29+ramp(t,11,12)*6),(9,29+ramp(t,11,12)*6),(17,24)],'#d8bc94',1.6)
 # Small hand-drawn reaction marks, timed to first rustle.
 if startle>.15:
  q=Pen(im)
  for x,y in [(453,210),(465,224)]:q.line([(x,y),(x+5,y-8)],INK,1.3)

def rabbit(im,t):
 if t<8.06:return
 u=ramp(t,8.06,9.75);x=778-174*u
 hops=math.sin(min(1,max(0,(t-8.06)/1.69))*math.pi*2)
 jump=abs(hops)*60*(1-ramp(t,9.45,9.8))
 y=399-jump
 settle=1+0.07*math.exp(-max(0,t-9.75)*6)*math.sin(max(0,t-9.75)*20) if t>9.75 else 1
 p=Pen(im,(x,y))
 p.ellipse((-28,0,29,6),'#b6af99',None)
 p.ellipse((-22,-33*settle,19,2),'#e6ddc6',w=1.3)
 p.ellipse((10,-17,28,-1),'#ede5d1',w=1.1)
 lean=math.sin(t*3)*1.3
 p.ellipse((-24,-71+lean,-14,-35),'#e8dfcb',w=1.2)
 p.ellipse((-12,-74-lean,-2,-36),'#e8dfcb',w=1.2)
 p.line([(-19,-63+lean),(-19,-43)],'#c2aaa1',2)
 p.line([(-7,-65-lean),(-7,-43)],'#c2aaa1',2)
 p.ellipse((-30,-45,4,-14),'#ece3cf',w=1.2)
 p.ellipse((-25,-31,-21,-26),INK,None)
 p.ellipse((-31,-23,-26,-19),'#9d8074',None)
 p.line([(-33,-20),(-40,-23)],INK,.65)
 p.line([(-32,-18),(-39,-17)],INK,.65)
 p.ellipse((-24,-4,-4,4),'#e8dfcb',w=1.1)
 p.ellipse((3,-3,23,4),'#e8dfcb',w=1.1)

def frame(t):
 im=BASE.copy()
 bush(im,t)
 human(im,t)
 rabbit(im,t)
 bush(im,t,True)
 # Sparse drifting leaves keep the quiet opening alive.
 p=Pen(im)
 for i in range(2):
  x=(560+t*15+i*130)%600+315;y=180+i*49+math.sin(t*1.5+i)*9
  p.curve([(x,y),(x+3,y-4),(x+7,y-3),(x+10,y)],'#8a9686',.8)
 return im.resize((W,H),Image.Resampling.LANCZOS)

SR=48000
rng=np.random.default_rng(615)
def envelope(n,attack=.01,release=.08):
 e=np.ones(n);a=min(n,int(SR*attack));r=min(n,int(SR*release))
 if a:e[:a]=np.sin(np.linspace(0,np.pi/2,a))**2
 if r:e[-r:]*=np.cos(np.linspace(0,np.pi/2,r))**2
 return e

def make_audio(path):
 n=SR*DURATION;t=np.arange(n)/SR;mix=np.zeros((n,2),dtype=np.float64)
 def put(sig,start,gain=1,pan=0):
  a=round(start*SR); b=min(n,a+len(sig)); sig=sig[:b-a]*gain
  if a<0 or b<=a:return
  mix[a:b,0]+=sig*math.sqrt((1-pan)/2);mix[a:b,1]+=sig*math.sqrt((1+pan)/2)
 def noise(dur,lo,hi):
  z=rng.normal(size=round(dur*SR));return sosfilt(butter(3,[lo,hi],btype='bandpass',fs=SR,output='sos'),z)
 def note(start,midi,dur,gain,pan=0):
  tt=np.arange(round(dur*SR))/SR;f=440*2**((midi-69)/12)
  sig=(np.sin(2*np.pi*f*tt)+.28*np.sin(2*np.pi*f*2*tt)+.1*np.sin(2*np.pi*f*3*tt))*np.exp(-tt*5)*envelope(len(tt),.007,.08)
  put(sig,start,gain,pan)
 # Wind: independent stereo filtered noise, gently modulated.
 for pan in [-.65,.65]:put(noise(15,80,800)*(0.65+.35*np.sin(t*.8+pan)),0,.075,pan)
 # Cricket groups: original pulse trains, with alternating stereo positions.
 for a in np.arange(.2,14.8,.53):
  for k in range(3):
   tt=np.arange(int(.035*SR))/SR
   sig=np.sin(2*np.pi*4300*tt+1.1*np.sin(2*np.pi*43*tt))*np.sin(np.linspace(0,np.pi,len(tt)))**2
   put(sig,a+k*.06,.014 if a<4 or a>11 else .007,.65 if int(a*2)%2 else -.7)
 # Quiet opening plucks, original sparse harmony.
 for a,m in [(0.25,50),(1.35,57),(2.55,62)]:note(a,m,1.4,.045,-.25)
 # Rustling exactly when the bush moves.
 for a,d in [(4,.8),(5.4,.7),(7.3,.85)]:
  z=noise(d,900,7500);tt=np.arange(len(z))/SR
  put(z*envelope(len(z),.035,.2)*(.4+.6*np.sin(2*np.pi*13*tt)**2),a,.19,.65)
 # Tense original ostinato with low semitone alternation.
 for i,a in enumerate(np.arange(4.15,7.95,.36)):
  note(a,[45,46,45,52][i%4],.33,.15,-.2)
  if i%2==0:note(a+.04,57,.25,.035,.3)
 # Comedic spring sound, synchronized with rabbit launch and second hop.
 for a,g in [(8.06,.23),(8.91,.12)]:
  tt=np.arange(int(.5*SR))/SR;f=220+580*np.exp(-tt*6)+75*np.sin(2*np.pi*12*tt)*np.exp(-tt*5)
  sig=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*7)*envelope(len(tt),.006,.06)
  put(sig,a,g,.4)
 for a in [8.9,9.75]:
  tt=np.arange(int(.13*SR))/SR
  put(np.sin(2*np.pi*100*tt)*np.exp(-tt*32)*envelope(len(tt),.004,.04),a,.10,.3)
 # Relieved exhale: breath band noise plus faint descending voiced component.
 z=noise(.92,350,2400);tt=np.arange(len(z))/SR
 put(z*np.sin(np.linspace(0,np.pi,len(z)))**1.5,11.12,.16,-.2)
 put(np.sin(2*np.pi*(150*tt-18*tt*tt))*np.sin(np.linspace(0,np.pi,len(z)))**2,11.12,.022,-.2)
 # Cheerful original C-major melody and soft bass.
 melody=[72,76,79,76,74,77,81,79,76,74,72]
 for i,m in enumerate(melody):note(11.35+i*.29,m,.5,.105,(-1)**i*.25)
 for a,m in [(11.35,48),(12.22,53),(13.09,55),(13.96,48)]:note(a,m,.9,.10,-.1)
 mix*=envelope(n,.15,.35)[:,None]
 peak=np.max(np.abs(mix));mix*=min(1,.82/peak)
 pcm=np.int16(np.clip(mix,-1,1)*32767)
 with wave.open(str(path),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR);f.writeframes(pcm.tobytes())
 print('Audio peak:',float(np.max(np.abs(mix))),'RMS:',float(np.sqrt(np.mean(mix*mix))),flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',default='build');ap.add_argument('--preview',action='store_true');args=ap.parse_args()
 out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
 for t in [2,4.5,8.45,11.8]:frame(t).save(out/f'preview_{t:g}.png')
 if args.preview:return
 make_audio(out/'soundtrack.wav')
 cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','30','-i','pipe:0','-i',str(out/'soundtrack.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-af','loudnorm=I=-18:TP=-1.5:LRA=9','-t','15','-movflags','+faststart',str(out/'first_night_1080p.mp4')]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 try:
  for i in range(450):
   proc.stdin.write(frame(i/FPS).tobytes())
   if i%90==0:print(f'Render {i}/450',flush=True)
  proc.stdin.close()
  if proc.wait():raise RuntimeError('FFmpeg failed')
 except BaseException:
  proc.kill();proc.wait();raise
 print('Finished',out/'first_night_1080p.mp4',flush=True)
if __name__=='__main__':main()
