# Источники и права

Получены непосредственно из NASA Image and Video Library. Проверено 12 ноября 2026.

Основание: NASA Media Usage Guidelines допускают фактическое информационное и редакционное использование собственных материалов NASA с указанием источника и без заявления об одобрении. Это не лицензия CC0 и не безусловное разрешение на любые рекламные применения. NASA-origin материалы обычно не охраняются авторским правом в США; отдельные сторонние материалы исключены.

Условия: https://www.nasa.gov/nasa-brand-center/images-and-media/

В карточках выбранных файлов не обнаружены обозначения стороннего правообладателя. В итоговый ролик включены только съёмки ракеты, корабля/Луны и приводнения; заставка NASA и лица людей исключены. Исходные аудиодорожки полностью исключены.

## launch — использован

Artemis I Launch (Press Site)

Источник: https://images.nasa.gov/details/Artemis%20I%20Launch%202022%20CU%20tracking%20from%20Press%20Site_compressed

Файл: https://images-assets.nasa.gov/video/Artemis I Launch 2022 CU tracking from Press Site_compressed/Artemis I Launch 2022 CU tracking from Press Site_compressed~large.mp4

Credit: NASA / MSFC

Длительность исходного архивного файла: 341.483000 с. Для монтажа отобраны короткие фрагменты, полный архив в финал не включён.

## moon — использован

Flight Day 6: Orion Approaches Moon

Источник: https://images.nasa.gov/details/Lunar%20Approach%20art001m1013251138_1

Файл: https://images-assets.nasa.gov/video/Lunar Approach art001m1013251138_1/Lunar Approach art001m1013251138_1~large.mp4

Credit: NASA / JSC

Длительность исходного архивного файла: 563.947000 с. Для монтажа отобраны короткие фрагменты, полный архив в финал не включён.

## earthrise — отклонён после просмотра

Earthrise after Orion Executes Outbound Powered Flyby

Источник: https://images.nasa.gov/details/ART-CMA1_2022_325_1250_SHARED_art001m1203251250

Файл: https://images-assets.nasa.gov/video/ART-CMA1_2022_325_1250_SHARED_art001m1203251250/ART-CMA1_2022_325_1250_SHARED_art001m1203251250~orig.mp4

Credit: NASA / JSC

Длительность исходного архивного файла: 457.166667 с. Для монтажа отобраны короткие фрагменты, полный архив в финал не включён.

Причина отклонения: почти чёрный кадр, Земля слишком мала для выразительного 30-секундного монтажа.

## landing — использован

Artemis I Orion Splashdown

Источник: https://images.nasa.gov/details/KSC-20221211-VP-MWC01-001-ARTEMIS-SPLASHDOWN-3296595

Файл: https://images-assets.nasa.gov/video/KSC-20221211-VP-MWC01-001-ARTEMIS-SPLASHDOWN-3296595/KSC-20221211-VP-MWC01-001-ARTEMIS-SPLASHDOWN-3296595~large.mp4

Credit: NASA / KSC

Длительность исходного архивного файла: 135.253000 с. Для монтажа отобраны короткие фрагменты, полный архив в финал не включён.
