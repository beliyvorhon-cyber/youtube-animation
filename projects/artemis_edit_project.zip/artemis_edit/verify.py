from pathlib import Path
import subprocess,json,hashlib,zipfile,io
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).parent;B=R/'build';p=B/'artemis_content_edit_1080p.mp4'
def cmd(a):return subprocess.check_output(a)
d=json.loads(cmd(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)]));v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['nb_frames'],v['codec_name'])==(1920,1080,'30/1','900','h264')
assert abs(float(d['format']['duration'])-30)<.05 and a['codec_name']=='aac' and a['sample_rate']=='48000' and a['channels']==2
subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
l=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-vn','-af','loudnorm=I=-16:TP=-1.8:LRA=9:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
ld=json.loads(l[l.rfind('{'):l.rfind('}')+1]);assert float(ld['input_tp'])<0
pcm=np.frombuffer(cmd(['ffmpeg','-v','error','-i',str(p),'-vn','-f','f32le','-acodec','pcm_f32le','-ar','48000','-ac','2','pipe:1']),dtype='<f4').reshape(-1,2)
rms=[float(np.sqrt(np.mean(pcm[i*48000:(i+1)*48000]**2))) for i in range(30)];assert min(rms)>1e-5
report={'duration_seconds':float(d['format']['duration']),'dimensions':[1920,1080],'fps':30,'frames':900,'video':'H.264 yuv420p','audio':'AAC stereo 48 kHz','full_decode':'pass','integrated_loudness_LUFS':float(ld['input_i']),'true_peak_dBTP':float(ld['input_tp']),'audio_RMS_each_second':rms,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_resolution_limit':'landing 720p upscaled; other selected sources native1080p','semantic_review':'Timestamped source contact sheets and event-focused samples; not every original source frame inspected.'}
(R/'quality_report.json').write_text(json.dumps(report,indent=2))
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
canvas=Image.new('RGB',(1280,4*205),'#101820');dr=ImageDraw.Draw(canvas)
for i,t in enumerate([1.8,5.8,10.7,14.6,18.5,22.4,27.65,28.7]):
 data=cmd(['ffmpeg','-v','error','-ss',str(t),'-i',str(p),'-frames:v','1','-vf','scale=640:360','-f','image2pipe','-vcodec','mjpeg','pipe:1'])
 im=Image.open(io.BytesIO(data));im.save(B/f'check_{t}.jpg')
 # two rows at 640x360 each -> 4 rows of 386
 if i==0:
  canvas=Image.new('RGB',(1280,1544),'#101820');dr=ImageDraw.Draw(canvas)
 x=(i%2)*640;y=(i//2)*386;canvas.paste(im,(x,y));dr.text((x+10,y+363),f'{t:.2f} s',fill='white',font=font)
canvas.save(B/'montage_preview.jpg',quality=92)
print(json.dumps(report,indent=2))
