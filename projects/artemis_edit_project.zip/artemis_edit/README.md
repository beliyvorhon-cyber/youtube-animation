# Artemis I: content-directed automatic editing test

A 30-second factual editorial montage made from official NASA camera recordings. This is an autonomous Codex editing experiment, not a NASA production or endorsement.

## Reproduce

Python 3.12+, FFmpeg 7 with libx264, AAC, drawtext and xfade; Pillow, NumPy, SciPy. DejaVu Sans fonts with Cyrillic coverage.

```
python3 -m pip install -r requirements.txt
python3 acquire.py
python3 edit.py
```

`acquire.py` downloads official archived source videos (roughly 1 GB in total), metadata and usage guidelines. No YouTube extraction, API key, paid service or stock soundtrack. `edit.py` produces `build/artemis_content_edit_1080p.mp4`, original synthesized WAV, title overlays and normalized shots. Delete numbered files in build/ to regenerate a changed shot; these are cached for the current edit decisions.

## Editorial process

1. Retrieved official NASA records and asset collections, reviewed usage policy and individual metadata; no third-party copyright claim appears in chosen item metadata.
2. Visually reviewed 16 timestamped thumbnails per candidate, then 16 more around launch ignition/liftoff and 16 around splashdown. Refined event boundaries from these visible actions. This is sampled-frame visual analysis, not a claim of inspecting every source frame or recognizing every possible event.
3. Rejected Earthrise: Earth appears as a tiny spot amid black, weak for a fast, mobile-readable short.
4. Kept ignition, launch tower clearance, isolated ascent, two legible Moon/Orion compositions, three inflated parachutes, then continuous splashdown. Details in edit_decisions.json and EDIT_REPORT.md.
5. Replaced all original audio with a new deterministic composition and synthesized effects. Rumble, swishes and water impact are editorial sound design, not historical field sound or sound recorded in space.
6. Applied two 0.4-second dissolves for changes of place/time, hard cuts for changes of scale within a scene, timed titles and explicit speed labels. Final impact plays in real time. All accelerated portions are labeled.

## Deliverables and source rights

SOURCES.md + sources.json: source URLs, credits, usage basis and rejected candidate. Metadata snapshots and source-usage HTML are in sources/. NASA-origin works are generally not copyrighted in the US; actual use follows NASA Media Usage Guidelines. This is not a CC0 declaration or a blanket right to use third-party materials, logos or people commercially. Titles acknowledge footage source and do not imply NASA approval.

The ZIP intentionally does not contain the 1 GB of original archives; acquire.py downloads them from the listed official URLs. The code, visual analysis, sources and quality report are included. No publication occurs when running the project.

## Quality limits

Output: 1920×1080, 30 fps, H.264 yuv420p, AAC 48 kHz stereo. The landing source is 1280×720 at 60 fps, upscaled with Lanczos; this does not create native 1080p detail. Launch and Moon sources are native 1920×1080. Source telemetry compression, exposure clipping in rocket exhaust and atmospheric softness remain visible. The lunar scene is accelerated 8× and a second view is cropped 1.1×; it is not interpolated or generated scenery.

The project demonstrates visual selection and reproducible editing of real footage. It does not establish general human-level editorial judgment: sampled analysis can miss brief events, music is basic synthesized scoring, and narrative information is conveyed in titles rather than voiceover.
