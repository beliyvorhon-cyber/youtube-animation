from pathlib import Path
import urllib.request,urllib.parse,json,concurrent.futures,subprocess
R=Path(__file__).parent;(R/'sources').mkdir(exist_ok=True)
ids={'launch':'Artemis I Launch 2022 CU tracking from Press Site_compressed','moon':'Lunar Approach art001m1013251138_1','earthrise':'ART-CMA1_2022_325_1250_SHARED_art001m1203251250','landing':'KSC-20221211-VP-MWC01-001-ARTEMIS-SPLASHDOWN-3296595'}
def get(url):return urllib.request.urlopen(urllib.parse.quote(url,safe=':/?=&%'),timeout=40)
def work(k,nid):
 url='https://images-assets.nasa.gov/video/'+nid+'/collection.json'
 collection=json.load(get(url));(R/'sources'/f'{k}_assets.json').write_text(json.dumps(collection,indent=2))
 print(k,[u for u in collection if u.endswith('.mp4')],flush=True)
 meta=json.load(get('https://images-api.nasa.gov/search?'+urllib.parse.urlencode({'nasa_id':nid})))
 (R/'sources'/f'{k}_metadata.json').write_text(json.dumps(meta,indent=2))
 candidates=[u for u in collection if u.endswith('.mp4')]
 selected=next((u for u in candidates if '~large.mp4' in u),next((u for u in candidates if '~orig.mp4' in u),candidates[0]))
 selected=selected.replace('http:','https:')
 p=R/'sources'/f'{k}.mp4'
 if not p.exists():
  with get(selected) as r,p.open('wb') as f:
   while data:=r.read(1024*1024):f.write(data)
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)]))
 (R/'sources'/f'{k}_probe.json').write_text(json.dumps(probe,indent=2))
 d=meta['collection']['items'][0]['data'][0]
 entry={'key':k,'nasa_id':nid,'title':d['title'],'description':d.get('description'),'credit':'NASA / '+d.get('center',''),'source_page':'https://images.nasa.gov/details/'+urllib.parse.quote(nid,safe=''),'download_url':selected,'local_file':f'sources/{k}.mp4','usage_terms':'https://www.nasa.gov/nasa-brand-center/images-and-media/','rights_basis':'NASA-origin media: US government work generally not copyrighted in the US; factual educational/editorial reuse under NASA Media Usage Guidelines, attribution, no implied endorsement. No third-party copyright notice found in the item metadata.','duration':probe['format']['duration']}
 print(k,p.stat().st_size,entry['duration'],[(s.get('width'),s.get('height'),s.get('r_frame_rate')) for s in probe['streams'] if s['codec_type']=='video'],flush=True)
 return entry
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:entries=list(pool.map(lambda kv:work(*kv),ids.items()))
(R/'sources.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False))
with get('https://www.nasa.gov/nasa-brand-center/images-and-media/') as r:(R/'sources/nasa_usage_guidelines.html').write_bytes(r.read())
