"""Reproducible content-directed edit of official NASA footage. No paid APIs.
Run acquire.py first, then this script. See edit_decisions.json and SOURCES.md.
"""
from pathlib import Path
import json,subprocess,math,wave,hashlib
import numpy as np
from scipy.signal import butter,sosfilt
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).parent;B=R/'build';B.mkdir(exist_ok=True)
SHOTS=[
 dict(id='01',source='launch',start=38,end=45,speed=1.4,duration=5,timeline_start=0,reason='Ignition becomes visible; omit preceding dark countdown. Hold the growth of the flame before cutting.'),
 dict(id='02',source='launch',start=49,end=57,speed=2,duration=4,timeline_start=5,reason='Rocket begins rising relative to the launch tower. Preserve visible clearance and growing plume.'),
 dict(id='03',source='launch',start=109,end=114,speed=1.25,duration=4,timeline_start=9,reason='Tracking camera isolates the ascending vehicle and exhaust after tower clearance; change of scale completes launch beat.'),
 dict(id='04',source='moon',start=80,end=115.2,speed=8,duration=4.4,timeline_start=12.6,reason='Both spacecraft at left and lunar disk at right are legible. Time compression exposes relative movement. 0.4-second dissolve signals change of time and place.'),
 dict(id='05',source='moon',start=270,end=302,speed=8,duration=4,timeline_start=17,reason='Moon is farther into frame; slightly tighter framing emphasizes the surface after the establishing composition.',zoom=1.1),
 dict(id='06',source='landing',start=87.4,end=94,speed=1.5,duration=4.4,timeline_start=20.6,reason='All three inflated parachutes and capsule are visible; descent establishes the return before touchdown. 0.4-second dissolve.'),
 dict(id='07',source='landing',start=96,end=101,speed=1,duration=5,timeline_start=25,reason='Horizon enters, capsule reaches ocean, splash blooms, parachutes unload. Keep continuous real-time action through impact.')]
(R/'edit_decisions.json').write_text(json.dumps(SHOTS,ensure_ascii=False,indent=2))

def run(cmd):subprocess.run(cmd,check=True)
def audio():
 sr=48000;n=30*sr;tt=np.arange(n)/sr;a=np.zeros((n,2));rng=np.random.default_rng(20261112)
 def env(n,attack=.01,release=.08):
  e=np.ones(n);na=min(n,int(sr*attack));nr=min(n,int(sr*release))
  if na:e[:na]*=np.sin(np.linspace(0,np.pi/2,na))**2
  if nr:e[-nr:]*=np.cos(np.linspace(0,np.pi/2,nr))**2
  return e
 def put(s,t,gain=1,pan=0):
  x=int(t*sr);l=min(len(s),n-x)
  if l<=0:return
  a[x:x+l,0]+=s[:l]*gain*math.sqrt((1-pan)/2);a[x:x+l,1]+=s[:l]*gain*math.sqrt((1+pan)/2)
 def tone(t,m,d,g,pan=0):
  v=np.arange(round(sr*d))/sr;f=440*2**((m-69)/12)
  sig=(np.sin(2*np.pi*f*v)+.22*np.sin(2*np.pi*f*2*v))*np.exp(-v*4.2)*env(len(v),.008,.08)
  put(sig,t,g,pan)
 def noise(d,lo,hi):return sosfilt(butter(3,[lo,hi],fs=sr,btype='bandpass',output='sos'),rng.normal(size=int(sr*d)))
 # Original D minor / Bb / F / C progression, 120 BPM, no borrowed melody.
 for k,t in enumerate(np.arange(0,29.5,.25)):
  chord=[[50,57,62,65],[46,53,58,62],[41,53,57,60],[48,55,60,64]][int(t//4)%4]
  m=chord[k%4]+12
  gain=.055 if 13<t<21 else .085
  tone(t,m,.6,gain,(-1)**k*.4)
 for k,t in enumerate(np.arange(0,29,1)):
  m=[38,34,41,36][int(t//4)%4];tone(t,m,1.25,.13)
 # Soft evolving pad, smoothly crossfaded chords.
 for i,t in enumerate([0,4,8,12,16,20,24,28]):
  v=np.arange(int(min(5,30-t)*sr))/sr
  chord=[[62,65,69],[58,62,65],[60,65,69],[60,64,67]][i%4]
  sig=sum(np.sin(2*np.pi*440*2**((m-69)/12)*v) for m in chord)/3
  put(sig*env(len(v),.8,1.1),t,.08)
 # Kick, soft snare and hats; reduce percussion in lunar section.
 for t in np.arange(1,29,.5):
  if 13<t<20.5 and int(t*2)%4:continue
  v=np.arange(int(.24*sr))/sr
  put(np.sin(2*np.pi*(48*v+65*.025*(1-np.exp(-v/.025))))*np.exp(-v*20)*env(len(v),.002,.04),t,.24)
  if int(t*2)%2:
   z=noise(.12,1000,7000);put(z*np.exp(-np.arange(len(z))/sr*32)*env(len(z),.002,.02),t,.06,.2)
  z=noise(.045,6000,12000);put(z*env(len(z),.001,.035),t+.25,.035,-.35)
 # Synthesized launch rumble; strongest at visible liftoff cut.
 z=noise(12.9,35,550);v=np.arange(len(z))/sr
 put(z*env(len(z),.2,1.1)*(.35+.65*np.minimum(v/5,1)),.1,.3)
 # Transition air sweeps are non-diegetic editorial sound design.
 for t in [4.65,8.65,12.35,16.65,20.35,24.65]:
  z=noise(.65,700,8500);put(z*np.sin(np.linspace(0,np.pi,len(z)))**2,t,.075,.3)
 # Water impact aligned to source ~98.5s => timeline 27.5s.
 z=noise(1.25,180,7000);v=np.arange(len(z))/sr
 put(z*np.exp(-v*4)*env(len(z),.012,.2),27.5,.32,.1)
 for m in [50,57,62,65,69]:tone(27.5,m,2.4,.09)
 a*=env(n,.05,.5)[:,None];a*=min(1,.85/np.max(np.abs(a)))
 with wave.open(str(B/'music_and_fx.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((a*32767).astype('<i2').tobytes())

def overlays():
 reg='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
 def make(name,title,sub,kicker='',footer=''):
  im=Image.new('RGBA',(1920,1080));d=ImageDraw.Draw(im)
  for y in range(770,1080):d.line((0,y,1919,y),fill=(5,12,21,int(190*(y-770)/310)),width=1)
  # Compact side label leaves central action and moon unobstructed.
  if kicker:d.text((90,815),kicker,font=ImageFont.truetype(bold,20),fill='#73ddd2')
  d.text((90,851),title,font=ImageFont.truetype(bold,48),fill='white')
  d.text((94,920),sub,font=ImageFont.truetype(reg,26),fill='#d9e4e9')
  d.rectangle((90,800,137,804),fill='#73ddd2')
  d.text((94,1027),footer or 'Кадры: NASA  •  Независимый автоматический монтаж',font=ImageFont.truetype(reg,18),fill='#b9cbd2')
  im.save(B/name)
 make('launch.png','ТУДА. И ОБРАТНО.','Artemis I · старт 16 ноября 2022','01 / ОТОРВАТЬСЯ ОТ ЗЕМЛИ')
 make('flight.png','ПУТЬ К ЛУНЕ','Беспилотный испытательный полёт','ARTEMIS I / 2022')
 make('moon.png','ЛУНА — РЯДОМ','Камера на корабле Orion · 21 ноября 2022','02 / СМЕНИТЬ ПЕРСПЕКТИВУ')
 make('landing.png','ВОЗВРАЩЕНИЕ','Три парашюта. Один последний манёвр.','03 / ВЕРНУТЬСЯ ДОМОЙ')
 make('end.png','КАСАНИЕ ОКЕАНА','11 декабря 2022 · миссия завершена','ARTEMIS I / ТУДА И ОБРАТНО','Видеоматериалы: NASA · Монтаж, титры и синтезированный звук: Codex · Без одобрения NASA')

def main():
 audio();overlays()
 # Normalize each content-selected shot independently (small memory footprint).
 for s in SHOTS:
  z=s.get('zoom',1)
  vf=f"setpts=(PTS-STARTPTS)/{s['speed']},fps=30,scale={int(1920*z)//2*2}:{int(1080*z)//2*2}:flags=lanczos,crop=1920:1080,setsar=1,format=yuv420p"
  dest=B/(s['id']+'.mp4')
  if dest.exists() and dest.stat().st_size>1000:
   print('Reuse shot',s['id'],flush=True);continue
  run(['ffmpeg','-v','error','-y','-ss',str(s['start']),'-t',str(s['end']-s['start']),'-i',str(R/'sources'/(s['source']+'.mp4')),'-an','-vf',vf,'-frames:v',str(round(s['duration']*30)),'-c:v','libx264','-crf','18','-preset','fast','-threads','2',str(dest)])
  print('Prepared shot',s['id'],flush=True)
 cmd=['ffmpeg','-v','error','-y','-filter_complex_threads','1']
 for s in SHOTS:cmd+=['-i',str(B/(s['id']+'.mp4'))]
 fc='[v0][v1][v2]concat=n=3:v=1:a=0[ac];[ac]fps=30,settb=AVTB[a];[a][v3]xfade=transition=fade:duration=0.4:offset=12.6[b];[b][v4]concat=n=2:v=1:a=0[cc];[cc]fps=30,settb=AVTB[c];[c][v5]xfade=transition=fade:duration=0.4:offset=20.6[d];[d][v6]concat=n=2:v=1:a=0[out]'
 fc=';'.join(f'[{i}:v]setpts=PTS-STARTPTS,fps=30,settb=AVTB[v{i}]' for i in range(7))+';'+fc
 if not (B/'picture.mp4').exists() or (B/'picture.mp4').stat().st_size<1000:
  run(cmd+['-filter_complex',fc,'-map','[out]','-an','-c:v','libx264','-crf','18','-preset','fast','-threads','2','-pix_fmt','yuv420p','-r','30','-frames:v','900',str(B/'picture.mp4')])
 cmd=['ffmpeg','-v','error','-y','-filter_complex_threads','1','-i',str(B/'picture.mp4'),'-i',str(B/'music_and_fx.wav')]
 for name in ['launch','flight','moon','landing','end']:cmd+=['-loop','1','-i',str(B/(name+'.png'))]
 intervals=[(0,8.8),(9,12.6),(13,20.6),(21,27.35),(27.5,30)]
 filters=[];prev='0:v'
 for i,(start,end) in enumerate(intervals):
  filters.append(f"[{prev}][{i+2}:v]overlay=enable='between(t,{start},{end})':shortest=1[v{i}]");prev=f'v{i}'
 # Accurate speed labels at each shot; overlays never claim real-time accelerated motion.
 for i,s in enumerate(SHOTS):
  label='РЕАЛЬНОЕ ВРЕМЯ' if s['speed']==1 else f"УСКОРЕНО ×{s['speed']:g}"
  start=s['timeline_start'];end=min(start+s['duration'],SHOTS[i+1]['timeline_start'] if i+1<len(SHOTS) else 30)-.01
  filters.append(f"[{prev}]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='{label}':fontsize=21:fontcolor=white:x=w-tw-90:y=70:box=1:boxcolor=black@0.45:boxborderw=10:enable='between(t,{start},{end})'[sp{i}]");prev=f'sp{i}'
 filters.append(f'[{prev}]fade=t=out:st=29.6:d=0.4[out]')
 run(cmd+['-filter_complex',';'.join(filters),'-map','[out]','-map','1:a','-af','loudnorm=I=-16:TP=-1.8:LRA=9','-ar','48000','-c:a','aac','-b:a','192k','-c:v','libx264','-preset','fast','-crf','18','-threads','2','-pix_fmt','yuv420p','-t','30','-r','30','-movflags','+faststart',str(B/'artemis_content_edit_1080p.mp4')])
 print('Finished',flush=True)
if __name__=='__main__':main()
