# Монтажные решения

Фильм: «Artemis I — туда и обратно». Реальные съёмки одной миссии, последовательность старт → Луна → океан.

| План | Исходник | In–Out исходника, с | Скорость | Начало в фильме, с | Выбор |
|---|---|---|---|---|---|
| 01 | launch | 38.000–45.000 | 1.4× | 0.000 | Ignition becomes visible; omit preceding dark countdown. Hold the growth of the flame before cutting. |
| 02 | launch | 49.000–57.000 | 2× | 5.000 | Rocket begins rising relative to the launch tower. Preserve visible clearance and growing plume. |
| 03 | launch | 109.000–114.000 | 1.25× | 9.000 | Tracking camera isolates the ascending vehicle and exhaust after tower clearance; change of scale completes launch beat. |
| 04 | moon | 80.000–115.200 | 8× | 12.600 | Both spacecraft at left and lunar disk at right are legible. Time compression exposes relative movement. 0.4-second dissolve signals change of time and place. |
| 05 | moon | 270.000–302.000 | 8× | 17.000 | Moon is farther into frame; slightly tighter framing emphasizes the surface after the establishing composition. |
| 06 | landing | 87.400–94.000 | 1.5× | 20.600 | All three inflated parachutes and capsule are visible; descent establishes the return before touchdown. 0.4-second dissolve. |
| 07 | landing | 96.000–101.000 | 1× | 25.000 | Horizon enters, capsule reaches ocean, splash blooms, parachutes unload. Keep continuous real-time action through impact. |

Планы 04 и 06 входят через наплыв 0,4 с, поэтому их начала перекрываются с предыдущими. Итог 30,000 с, 900 кадров.

## Звук
Оригинальная последовательность аккордов и арпеджио, 120 BPM. Доля 0,5 с согласована с основными монтажными акцентами. Шумовой рокот усиливается при отрыве ракеты; пространство у Луны получает более редкую перкуссию; всплеск в 27,5 с соответствует касанию воды около 98,5 с исходника. Все звуки синтезированы, исходная звуковая дорожка удалена.

## Отказ от слабого материала
Earthrise был загружен и просмотрен, но не использован: малый размер Земли и практически чёрное поле не выдерживают темп этого ролика. Это результат анализа содержания, а не случайного отбора интервалов.

## Метод и пределы
Визуальный анализ контактных листов с таймкодами, уточнение значимых событий, проверка конечных кадров. Не каждый кадр каждого полного архива просмотрен семантически. Итоговый файл полностью декодирован технической проверкой. Оценку эмоционального впечатления должен дать зритель.
