from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,concurrent.futures
R=Path(__file__).parent;(R/'analysis').mkdir(exist_ok=True)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
def sheet(key,times,label):
 canvas=Image.new('RGB',(1280,4*205),'#11151b');d=ImageDraw.Draw(canvas)
 for i,t in enumerate(times):
  data=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(R/'sources'/f'{key}.mp4'),'-frames:v','1','-vf','scale=320:180:force_original_aspect_ratio=decrease,pad=320:180:(ow-iw)/2:(oh-ih)/2','-f','image2pipe','-vcodec','mjpeg','pipe:1'])
  import io
  im=Image.open(io.BytesIO(data));x=(i%4)*320;y=(i//4)*205;canvas.paste(im,(x,y));d.text((x+5,y+183),f'{key}  {t:.2f}s',font=font,fill='white')
 canvas.save(R/'analysis'/f'{label}.jpg',quality=90)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  tasks=[]
  for key in ['launch','moon','earthrise','landing']:
   dur=float(json.loads((R/'sources'/f'{key}_probe.json').read_text())['format']['duration'])
   tasks.append(pool.submit(sheet,key,[i*(dur-1)/15 for i in range(16)],key+'_overview'))
  for f in tasks:f.result()
